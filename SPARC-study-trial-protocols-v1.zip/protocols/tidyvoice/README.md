# TidyVoiceX-ASV development protocol

This recipe reconstructs the exact enrollment/test order, study trial ID and target label for all three SPARC partitions from the challenge's development trial pairs. Python 3.8 or later and the standard library are sufficient. The recipe uses the pair list alone.

Obtain `TidyVocieX_Dev_trialPairs.zip` from the development trial-pairs link on the [TidyVoice challenge dataset page](https://tidyvoice2026.github.io/2_dataset_download/). The spelling “Vocie” is part of the upstream filename. The archive contains `TidyVocieX_Dev_trialPairs.txt`. The [Mozilla Data Collective corpus page](https://mozilladatacollective.com/datasets/cmihtsewu023so207xot1iqqw) describes corpus access and the permitted speaker-verification use. Obtain the development audio separately from the corpus provider if you need waveforms.

From this directory, run:

```sh
python3 reconstruct.py /path/to/TidyVocieX_Dev_trialPairs.zip --output-dir ./tidyvoice-trials
```

The output directory must be new. The command accepts the extracted text file as well. To validate every record without saving the TSVs, replace `--output-dir ./tidyvoice-trials` with `--verify-only`. The program checks the upstream text digest, output counts and SHA-256 for every partition. Study-pinned archive, text and TSV digests are in [checksums.json](checksums.json).

| Output | Speakers | Trials | Target | Non-target |
| --- | ---: | ---: | ---: | ---: |
| calibration.tsv | 485 | 5,372,011 | 2,541,166 | 2,830,845 |
| validation.tsv | 162 | 1,169,874 | 810,257 | 359,617 |
| test.tsv | 161 | 922,640 | 648,577 | 274,063 |

Each TSV uses UTF-8, tab separators and LF line endings, including its header. The columns are `trial_id`, `enrollment`, `test`, and `label`. Enrollment and test are paths relative to the development audio root, in the exact upstream orientation. Label 1 is a target trial and 0 is a non-target trial. The numeric suffix in `tidyvoice_asv:dev:NNNNNNNN` is the **one-based line number** in the original pair list. For example, suffix `00000005` denotes the fifth line.

The speaker ID is the first path component of each endpoint. The recipe ranks the 808 distinct speakers by SHA-256 of the UTF-8 seed `tidyvoice_asv_speaker_split_v1`, a zero byte, and the speaker ID, sorting the digest bytes in ascending order. Ranks 1–485 enter calibration, 486–647 enter validation, and 648–808 enter test. A trial is retained when both speakers belong to the same partition. This excludes 4,535,475 cross-partition trials from the 12,000,000 upstream pairs. Each partition retains the source-line order.

For verification, the expected TSV digests were calculated independently from the frozen study protocol CSVs. The ordered trial IDs, enrollment observation IDs, test observation IDs and labels were also compared with all three model-input partitions and held-out test labels. In the study cache, the observation ID for either relative path was `tidyvoice_dev:` followed by the first 24 hexadecimal digits of its UTF-8 SHA-256.
