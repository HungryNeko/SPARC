# SPARC LibriSpeech trial lists

From the parent directory run the following command with Python 3.8 or later.

```sh
python3 generate_ranked_trials.py librispeech --output output/librispeech
```

The command expands the three included inventories into UTF-8 TSV files with a header and LF line endings. Each row contains the study's original protocol ID, trial ID, enrollment and probe observation IDs (in that order), and binary label (1 = same speaker). Rows follow the original trial-ID order. The program verifies the full file SHA-256 against `checksums.json` for each split.

| Split | Source partition | Trials | Targets |
|---|---|---:|---:|
| Calibration | dev-clean | 29,293 | 2,663 |
| Validation | dev-other | 31,141 | 2,831 |
| Test | test-clean and test-other | 60,346 | 5,486 |

The included endpoint is a native LibriSpeech utterance stem. For example, a stem of the form `speaker-chapter-utterance` identifies `<partition>/<speaker>/<chapter>/<stem>.flac`. The enrollment for each speaker was the longest utterance, with ties broken by lexicographic utterance ID. Each remaining utterance provides one target and ten non-target trials. The inventory saves that enrollment choice (E) or the deterministic zero-based offset into the sorted list of other speakers used to generate the ten non-targets. No audio or machine-learning package is required to read the lists.

These project-defined speaker-verification trials use LibriSpeech from V. Panayotov, G. Chen, D. Povey and S. Khudanpur, *LibriSpeech: An ASR Corpus Based on Public Domain Audio*, ICASSP 2015. The OpenSLR source and corpus metadata carry CC BY 4.0. The SPARC authors selected the partitions and constructed the verification trial lists.

- [LibriSpeech downloads and license](https://www.openslr.org/12/)
- [Creative Commons Attribution 4.0](https://creativecommons.org/licenses/by/4.0/)
