#!/usr/bin/env python3
"""Expand and verify the LibriSpeech or VoxCeleb2 SPARC trial lists."""
import argparse
import csv
import hashlib
import json
import re
import tempfile
from pathlib import Path, PurePosixPath
from zipfile import ZipFile

SPLITS = ("calibration", "validation", "test")
HEADER = ("protocol_id", "trial_id", "enroll_observation_id", "test_observation_id", "label")
AUDIO_EXTENSIONS = {".m4a", ".aac", ".flac", ".wav"}
PROTOCOLS = {
    "librispeech": "librispeech_fixed_1plus10_v1",
    "voxceleb2": "voxceleb2_test_speaker_disjoint_1plus10_v1",
}


def short_hash(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:24]


def vox_lookup(source):
    """Read native names from an authorized local archive or extracted audio tree."""
    mapping = {}

    def add_name(name):
        path = PurePosixPath(name.replace("\\", "/"))
        if path.suffix.lower() not in AUDIO_EXTENSIONS or len(path.parts) < 3:
            return
        speaker, video, _ = path.parts[-3:]
        if re.fullmatch(r"id[0-9]+", speaker):
            native = "voxceleb2_test:" + "/".join((speaker, video, path.stem))
            token = short_hash(native)
            if mapping.setdefault(token, native) != native:
                raise ValueError("Multiple native endpoints map to the same token")

    if source.is_dir():
        for path in source.rglob("*"):
            if path.is_file():
                add_name(path.relative_to(source).as_posix())
    else:
        with ZipFile(source) as archive:
            for name in archive.namelist():
                add_name(name)
    return mapping


def expand(corpus, split, inventory, mapping):
    protocol = PROTOCOLS[corpus]
    by_speaker = {}
    probes = []
    with inventory.open(encoding="utf-8", newline="") as stream:
        for record in csv.DictReader(stream, delimiter="\t"):
            token = record["endpoint"]
            speaker = int(record["speaker_group"])
            if corpus == "librispeech":
                endpoint = "librispeech:" + token
            elif mapping is None:
                endpoint = "voxanon:" + token
            else:
                if token not in mapping:
                    raise ValueError(f"VoxCeleb2 audio inventory is missing endpoint token {token}")
                endpoint = mapping[token]
            assignment = record["assignment"]
            if assignment == "E":
                if speaker in by_speaker:
                    raise ValueError("Multiple enrollments for one speaker")
                by_speaker[speaker] = endpoint
            else:
                probes.append((speaker, endpoint, int(assignment)))

    speakers = sorted(by_speaker)
    alternatives = {k: [s for s in speakers if s != k] for k in speakers}
    rows = []
    masked = corpus == "voxceleb2" and mapping is None
    for speaker, probe, offset in probes:
        candidates = alternatives[speaker]
        if not 0 <= offset < len(candidates):
            raise ValueError("Invalid impostor offset")
        group = [speaker] + [candidates[(offset + i) % len(candidates)] for i in range(10)]
        for index, selected in enumerate(group):
            enroll = by_speaker[selected]
            trial_id = split + ":" + short_hash(enroll + "|" + probe)
            if masked:
                trial_id = "opaque:" + trial_id
            rows.append((protocol, trial_id, enroll, probe, int(index == 0)))
    rows.sort(key=lambda row: row[1])
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("corpus", choices=PROTOCOLS)
    parser.add_argument("--output", type=Path, required=True, help="Directory for three verified TSV files")
    parser.add_argument("--source", type=Path, help="VoxCeleb2 Test audio ZIP or extracted tree, to recover native keys")
    args = parser.parse_args()
    if args.source and args.corpus != "voxceleb2":
        parser.error("--source applies only to VoxCeleb2. LibriSpeech uses native keys by default.")
    directory = Path(__file__).resolve().parent / args.corpus
    expected = json.loads((directory / "checksums.json").read_text(encoding="utf-8"))
    mapping = vox_lookup(args.source) if args.source else None
    view = "opaque" if args.corpus == "voxceleb2" and mapping is None else "native"
    args.output.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=args.output) as work:
        for split in SPLITS:
            rows = expand(args.corpus, split, directory / (split + ".inventory.tsv"), mapping)
            path = Path(work) / (split + ".tsv")
            with path.open("w", encoding="utf-8", newline="") as stream:
                writer = csv.writer(stream, delimiter="\t", lineterminator="\n")
                writer.writerow(HEADER)
                writer.writerows(rows)
            check = expected[view][split]
            if len(rows) != check["rows"] or hashlib.sha256(path.read_bytes()).hexdigest() != check["sha256"]:
                raise ValueError(f"{split} verification failed for the {view} list")
        for split in SPLITS:
            name = split + ".tsv"
            (Path(work) / name).replace(args.output / name)
            print(f"{args.corpus} {split}: {expected[view][split]['rows']:,} verified {view} trials")


if __name__ == "__main__":
    main()
