"""Read the frozen SPARC NISP trial lists. Requires Python 3.8+."""
import argparse
import gzip
import hashlib
import json
import struct
import sys
from pathlib import Path

DIRECTORY = Path(__file__).resolve().parent
PAIR = struct.Struct("<HH")


def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:24]


def read_split(split, audio_root, output):
    manifest = json.loads((DIRECTORY / "manifest.json").read_text())
    ids = (DIRECTORY / "observation_ids.txt").read_text().splitlines()
    if len(ids) != len(set(ids)) or len(ids) >= 32768:
        raise ValueError("Invalid observation dictionary")

    paths = {}
    if audio_root is not None:
        for path in audio_root.rglob("*.wav"):
            relative = path.relative_to(audio_root).as_posix()
            paths[digest(relative)] = relative
        missing = set(ids).difference(paths)
        if missing:
            raise ValueError(f"{len(missing)} study utterances absent. Check the extracted audio root.")

    expected = manifest["splits"][split]
    expected_digest = expected["native_tsv_sha256" if audio_root else "opaque_tsv_sha256"]
    check = hashlib.sha256()
    positives = rows = 0

    def write(line):
        encoded = (line + "\n").encode("utf-8")
        output.write(encoded)
        check.update(encoded)

    write("trial_id\tenroll_path\ttest_path\tlabel" if audio_root else
          "enroll_observation_id\ttest_observation_id\tlabel")
    with gzip.open(DIRECTORY / (split + ".pairs.gz"), "rb") as source:
        while True:
            block = source.read(PAIR.size * 65536)
            if not block:
                break
            for left, right in PAIR.iter_unpack(block):
                label = str(right >> 15)
                enroll = ids[left]
                test = ids[right & 32767]
                if audio_root is None:
                    write(f"nisp:{enroll}\tnisp:{test}\t{label}")
                else:
                    enroll_path, test_path = paths[enroll], paths[test]
                    record = "\0".join(("nisp_amecxsv_v1", split, label, enroll_path, test_path))
                    write(f"nisp_{digest(record)}\t{enroll_path}\t{test_path}\t{label}")
                positives += int(label)
                rows += 1
    if (rows, positives, check.hexdigest()) != (expected["rows"], expected["targets"], expected_digest):
        raise ValueError("Trial-list count or checksum mismatch")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("split", choices=["calibration", "validation", "test"])
    parser.add_argument("--audio-root", type=Path, help="Directory containing the extracted *_master folders")
    args = parser.parse_args()
    read_split(args.split, args.audio_root, sys.stdout.buffer)
