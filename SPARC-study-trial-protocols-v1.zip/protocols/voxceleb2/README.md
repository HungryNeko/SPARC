# SPARC VoxCeleb2 trial lists

From the parent directory, run the following command with Python 3.8 or later to reconstruct every oriented trial and its binary label using opaque utterance identifiers.

```sh
python3 generate_ranked_trials.py voxceleb2 --output output/voxceleb2
```

To recover the study's original observation IDs, trial IDs and trial-ID order, supply a locally obtained VoxCeleb2 Test audio ZIP or extracted tree. The reader uses only member names of the form `idXXXXX/video/segment.ext` (`.m4a`, `.aac`, `.wav`, or `.flac`). It never reads audio samples or needs Internet access.

```sh
python3 generate_ranked_trials.py voxceleb2 --source /path/to/vox2_test_aac.zip --output output/voxceleb2-native
```

Both paths produce UTF-8, LF-terminated TSVs with a header. Each row contains the protocol ID, trial ID, enrollment and probe observation IDs, and label (1 = same speaker). Opaque trial IDs begin with `opaque:` and are sorted separately from the original IDs. Each view has its own full-file SHA-256 in `checksums.json`. The native hashes were calculated directly from the keyed frozen study trials and labels.

| Split | Speakers | Trials | Targets |
|---|---:|---:|---:|
| Calibration | 40 | 134,354 | 12,214 |
| Validation | 39 | 147,455 | 13,405 |
| Test | 39 | 115,500 | 10,500 |

These trials use all 118 speakers from the VoxCeleb2 Test audio archive. The study sorted speaker IDs by SHA-256 of `asv2026-voxceleb2-test-blind-v1:<speaker>`, then assigned 40, 39 and 39 speakers to the splits. The longest utterance per speaker provided the enrollment endpoint, using lexicographic utterance ID to break ties. Every other utterance provided a target trial and ten non-target trials with different speakers. The inventory preserves the enrollment choice (E) or the zero-based starting position for drawing the ten non-target speakers from the sorted alternatives. Each endpoint token is the first 24 hex characters of SHA-256 of the UTF-8 original observation ID `voxceleb2_test:<speaker>/<video>/<segment>`. This lets users map trials to their own copy without embedding source-media links in the distributed list.

SPARC's verification trials are a project-defined derivative of VoxCeleb2 metadata by J. S. Chung, A. Nagrani and A. Zisserman, *VoxCeleb2: Deep Speaker Recognition*, Interspeech 2018. The source metadata and these adapted trial inventories are available under CC BY-SA 4.0. SPARC created the split and pairing and replaced public endpoint strings with tokens. The corpus providers manage access to audio/video separately.

- [Oxford dataset description and metadata license](https://www.robots.ox.ac.uk/~vgg/data/voxceleb/vox2.html)
- [KAIST VoxCeleb page and audio/video access request](https://mm.kaist.ac.kr/datasets/voxceleb/)
- [Creative Commons Attribution-ShareAlike 4.0](https://creativecommons.org/licenses/by-sa/4.0/)
