# NISP trial lists

The three compressed lists contain the enrollment and test utterances and the binary verification label for every NISP trial in the SPARC study, in the order used for the experiments. Calibration contains 322,073 rows, validation 196,449, and test 380,160. A label of 1 denotes the same speaker.

To write the test list with the study’s stable observation identifiers, run the command below from this directory. This mode only needs Python 3.8 or later.

```sh
python3 read_trials.py test > test.tsv
```

To resolve the identifiers to audio paths and the original study trial IDs, obtain NISP from the dataset authors, extract the audio archives into a common directory containing the language-specific `*_master` directories, then pass that directory to the reader.

```sh
python3 read_trials.py test --audio-root /path/to/extracted-nisp > test-native.tsv
```

Use `calibration` or `validation` in place of `test` for the other splits. Each run checks the emitted TSV against the corresponding SHA-256 in `manifest.json`. Hashes are for UTF-8 TSV including the header and LF line endings.

## File format

Each row of `observation_ids.txt` stores one observation digest. Its zero-based row number is the dictionary index. The digest is the first 24 lowercase hexadecimal characters of SHA-256 of the source-relative POSIX audio path encoded as UTF-8. Each gzipped trial file contains pairs of little-endian unsigned 16-bit integers. The first integer is the enrollment index. The low 15 bits of the second integer are the test index and its high bit is the binary target label.

## Data attribution

The study's calibration, validation and test pairings adapt NISP by Shareef Babu Kalluri, Deepu Vijayasenan, Sriram Ganapathy, Ragesh Rajan M and Prashant Krishnan, *NISP: A Multi-lingual Multi-accent Dataset for Speaker Profiling* (ICASSP 2021). The source data are licensed under CC BY 4.0. The exact source repository revision used was `d8ee6a15e1c188ca649b0c5d80a4dcde673882fe`. Only the study protocol is distributed here.

[NISP source and terms](https://github.com/iiscleap/NISP-Dataset/tree/d8ee6a15e1c188ca649b0c5d80a4dcde673882fe) · [Dataset paper](https://doi.org/10.1109/ICASSP39728.2021.9414349) · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)
