"""Recreate the three SPARC TidyVoiceX Dev trial lists from the official pairs."""
import argparse
import hashlib
import json
import os
from collections import Counter
from contextlib import ExitStack
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
SPLITS = ("calibration", "validation", "test")
NATIVE_NAME = "TidyVocieX_Dev_trialPairs.txt"
HEADER = b"trial_id\tenrollment\ttest\tlabel\n"


def open_pairs(path, stack):
    if path.suffix.lower() == ".zip":
        archive = stack.enter_context(ZipFile(path))
        return stack.enter_context(archive.open(NATIVE_NAME))
    return stack.enter_context(path.open("rb"))


def verify_source(path, expected):
    digest = hashlib.sha256()
    speakers = set()
    with ExitStack() as stack:
        for line in open_pairs(path, stack):
            digest.update(line)
            _, enroll, test = line.split()
            speakers.add(enroll.split(b"/", 1)[0])
            speakers.add(test.split(b"/", 1)[0])
    if digest.hexdigest() != expected["source_sha256"] or len(speakers) != 808:
        raise ValueError("Official trial list does not match the study-pinned SHA-256 and speaker count")
    return speakers


def speaker_assignments(speakers):
    seed = b"tidyvoice_asv_speaker_split_v1\0"
    ranked = sorted(speakers, key=lambda s: (hashlib.sha256(seed + s).digest(), s))
    roles = {}
    start = 0
    for split, size in zip(SPLITS, (485, 162, 161)):
        roles.update(dict.fromkeys(ranked[start:start + size], split))
        start += size
    return roles


def reconstruct(path, expected, folder):
    roles = speaker_assignments(verify_source(path, expected))
    digests = {s: hashlib.sha256(HEADER) for s in SPLITS}
    targets, totals = Counter(), Counter()
    source_rows = 0
    with ExitStack() as stack:
        files = {}
        if folder is not None:
            for split in SPLITS:
                files[split] = stack.enter_context((folder / (split + ".tsv")).open("xb"))
                files[split].write(HEADER)
        for source_rows, line in enumerate(open_pairs(path, stack), 1):
            label, enrollment, test = line.split()
            left = roles[enrollment.split(b"/", 1)[0]]
            right = roles[test.split(b"/", 1)[0]]
            if left != right:
                continue
            trial_id = f"tidyvoice_asv:dev:{source_rows:08d}".encode("ascii")
            record = b"\t".join((trial_id, enrollment, test, label)) + b"\n"
            digests[left].update(record)
            totals[left] += 1
            targets[left] += label == b"1"
            if folder is not None:
                files[left].write(record)
    if source_rows != expected["source_rows"]:
        raise ValueError("Source trial count differs from the study protocol")
    for split in SPLITS:
        actual = dict(rows=totals[split], target=targets[split],
                      nontarget=totals[split] - targets[split], sha256=digests[split].hexdigest())
        if actual != expected["splits"][split]:
            raise ValueError(f"{split} differs from the study protocol: {actual}")
        print(f"{split}  {totals[split]:,} trials  {actual['sha256']}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pairs", type=Path, help="Official Dev trial-pair ZIP or its extracted text member")
    output = parser.add_mutually_exclusive_group(required=True)
    output.add_argument("--output-dir", type=Path, help="New directory for three TSV files")
    output.add_argument("--verify-only", action="store_true", help="Verify the same records without writing files")
    args = parser.parse_args()
    expected = json.loads((ROOT / "checksums.json").read_text(encoding="utf-8"))
    if args.verify_only:
        reconstruct(args.pairs, expected, None)
        return
    dest = args.output_dir
    if dest.exists():
        parser.error("The output directory must be new")
    dest.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".sparc-tidyvoice-", dir=dest.parent) as tmp:
        staged = Path(tmp) / "verified"
        staged.mkdir()
        reconstruct(args.pairs, expected, staged)
        if dest.exists():
            raise FileExistsError(dest)
        os.rename(staged, dest)


if __name__ == "__main__":
    main()
