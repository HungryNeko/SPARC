# SPARC study trial lists

These protocols reproduce the enrollment and test pairings, labels and split assignments used in *SPARC: Portable Anchored Residual Calibration Plug-in for Speaker Verification*. The three splits for each corpus correspond to calibration fitting, model selection and held-out evaluation. Together they cover 8,881,296 trials.

| Corpus and instructions | Calibration | Validation | Test | How to obtain the list |
| --- | ---: | ---: | ---: | --- |
| [TidyVoice](tidyvoice/README.md) | 5,372,011 | 1,169,874 | 922,640 | Run the supplied script on the challenge's official development trial-pairs file. |
| [NISP](nisp/README.md) | 322,073 | 196,449 | 380,160 | Expand the bundled pair lists. A local NISP installation resolves the opaque keys to native filenames and trial IDs. |
| [LibriSpeech](librispeech/README.md) | 29,293 | 31,141 | 60,346 | Expand the bundled inventories directly to labeled pairs with native utterance keys. |
| [VoxCeleb2](voxceleb2/README.md) | 134,354 | 147,455 | 115,500 | Expand the bundled inventories to labeled pairs. An authorized local VoxCeleb2 Test archive resolves native utterance keys. |

Each corpus guide gives the commands, original source, usage terms and checksum procedure. Outputs use tab-separated UTF-8 text. A label of 1 denotes a target trial and 0 denotes a nontarget trial. Checksums for native trial lists were verified against the executed study inputs, including split, direction, labels and order. The audio remains available through each corpus provider under its own terms.
